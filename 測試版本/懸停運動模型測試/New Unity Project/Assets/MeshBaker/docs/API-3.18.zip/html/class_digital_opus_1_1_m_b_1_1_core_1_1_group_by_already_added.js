var class_digital_opus_1_1_m_b_1_1_core_1_1_group_by_already_added =
[
    [ "Compare", "class_digital_opus_1_1_m_b_1_1_core_1_1_group_by_already_added.html#a6540f2adedc48742497d4d2246d3c379", null ],
    [ "GetDescription", "class_digital_opus_1_1_m_b_1_1_core_1_1_group_by_already_added.html#a89db12800a7e3adf8f2b7e14df1801c2", null ],
    [ "GetName", "class_digital_opus_1_1_m_b_1_1_core_1_1_group_by_already_added.html#a15bac75de3c52b8fedac4e12e6bc6fd3", null ]
];