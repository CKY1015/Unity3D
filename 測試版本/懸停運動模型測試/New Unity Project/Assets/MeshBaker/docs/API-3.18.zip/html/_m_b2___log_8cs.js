var _m_b2___log_8cs =
[
    [ "MB2_Log", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b2___log.html", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b2___log" ],
    [ "ObjectLog", "class_digital_opus_1_1_m_b_1_1_core_1_1_object_log.html", "class_digital_opus_1_1_m_b_1_1_core_1_1_object_log" ],
    [ "MB2_LogLevel", "_m_b2___log_8cs.html#ad2c4d102326041d70cf945d3434e7772", [
      [ "none", "_m_b2___log_8cs.html#ad2c4d102326041d70cf945d3434e7772a334c4a4c42fdb79d7ebc3e73b517e6f8", null ],
      [ "error", "_m_b2___log_8cs.html#ad2c4d102326041d70cf945d3434e7772acb5e100e5a9a3e7f6d1fd97512215282", null ],
      [ "warn", "_m_b2___log_8cs.html#ad2c4d102326041d70cf945d3434e7772a1ea4c3ab05ee0c6d4de30740443769cb", null ],
      [ "info", "_m_b2___log_8cs.html#ad2c4d102326041d70cf945d3434e7772acaf9b6b99962bf5c2264824231d7a40c", null ],
      [ "debug", "_m_b2___log_8cs.html#ad2c4d102326041d70cf945d3434e7772aad42f6697b035b7580e4fef93be20b4d", null ],
      [ "trace", "_m_b2___log_8cs.html#ad2c4d102326041d70cf945d3434e7772a04a75036e9d520bb983c5ed03b8d0182", null ]
    ] ]
];