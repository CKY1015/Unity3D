var class_digital_opus_1_1_m_b_1_1_core_1_1_m_b_version_editor =
[
    [ "GetPlatformString", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b_version_editor.html#a98e77ca5059b0e3267af7be5f2c7973b", null ],
    [ "RegisterUndo", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b_version_editor.html#ac3c192a54e742e44c51974369497ed99", null ],
    [ "SetInspectorLabelWidth", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b_version_editor.html#a97b27adc9f7cd57e30d513f69ca41d9d", null ]
];