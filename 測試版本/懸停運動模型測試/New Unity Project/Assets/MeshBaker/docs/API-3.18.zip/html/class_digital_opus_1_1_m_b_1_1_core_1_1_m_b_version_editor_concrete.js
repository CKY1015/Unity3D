var class_digital_opus_1_1_m_b_1_1_core_1_1_m_b_version_editor_concrete =
[
    [ "GetPlatformString", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b_version_editor_concrete.html#a46c63f3a28d1535ffbd04db9961eec60", null ],
    [ "RegisterUndo", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b_version_editor_concrete.html#ac7d955a6b607eaabec96ff48d05b8826", null ],
    [ "SetInspectorLabelWidth", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b_version_editor_concrete.html#a6e18abbcc114ab3fe893a6c3712b150d", null ]
];