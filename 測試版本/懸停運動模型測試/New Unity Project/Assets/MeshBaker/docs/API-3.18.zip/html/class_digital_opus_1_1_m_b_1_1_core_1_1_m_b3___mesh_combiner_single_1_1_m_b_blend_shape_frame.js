var class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___mesh_combiner_single_1_1_m_b_blend_shape_frame =
[
    [ "frameWeight", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___mesh_combiner_single_1_1_m_b_blend_shape_frame.html#a69b7cf650d3732835bab7dc5efe6823f", null ],
    [ "normals", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___mesh_combiner_single_1_1_m_b_blend_shape_frame.html#a7f53c025966dcf0b942a9a4968f5fc42", null ],
    [ "tangents", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___mesh_combiner_single_1_1_m_b_blend_shape_frame.html#ac0e1b9f7d0e6be00353b1cd488604bce", null ],
    [ "vertices", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___mesh_combiner_single_1_1_m_b_blend_shape_frame.html#a28892669efa1eaf80e3d0cdec3b3f011", null ]
];