var class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___multi_mesh_combiner_1_1_combined_mesh =
[
    [ "CombinedMesh", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___multi_mesh_combiner_1_1_combined_mesh.html#a6e9bcae61a873cf01ec952a8a33cbf11", null ],
    [ "isEmpty", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___multi_mesh_combiner_1_1_combined_mesh.html#ae1980880f5fb6e63275385f993f2ac95", null ],
    [ "combinedMesh", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___multi_mesh_combiner_1_1_combined_mesh.html#a4a513739292867ddf10ba3a23d3cd0d3", null ],
    [ "extraSpace", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___multi_mesh_combiner_1_1_combined_mesh.html#a239e3ec731575bb72fd132e62f011c0d", null ],
    [ "gosToAdd", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___multi_mesh_combiner_1_1_combined_mesh.html#a8266cebc5ff4e80df92660a95b351bb9", null ],
    [ "gosToDelete", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___multi_mesh_combiner_1_1_combined_mesh.html#a8139439ee91117f6364581d4c41604b7", null ],
    [ "gosToUpdate", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___multi_mesh_combiner_1_1_combined_mesh.html#a34e159ef845e595bd7739826ed53cdcb", null ],
    [ "isDirty", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___multi_mesh_combiner_1_1_combined_mesh.html#a4240c4253864a55249d734478bc79e91", null ],
    [ "numVertsInListToAdd", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___multi_mesh_combiner_1_1_combined_mesh.html#ac13dac798ee0af77044198746931f893", null ],
    [ "numVertsInListToDelete", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___multi_mesh_combiner_1_1_combined_mesh.html#aaea65a7aa0b20ff879ca629d6ef6e22e", null ]
];